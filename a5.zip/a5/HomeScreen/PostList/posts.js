export default [
  {
    avatarIcon: "relativity.jpeg",
    userName: "Relativity Space",
    handle: "relativityspace",
    time: "2h",
    title: "Web Development",
    contentTitle: "Title",
    content:
      "React.js is a component based front end library that makes it very easy to build Single Page Applications or SPAs",
    image: "../../images/react-blue.png",
    discuss: "4.2K",
    forward: "3.5K",
    like: "37.5K",
  },
  {
    avatarIcon: "relativity.jpeg",
    userName: "Relativity Space",
    handle: "relativityspace",
    time: "2h",
    title: "Web Development",
    contentTitle: "Title",
    content:
      "React.js is a component based front end library that makes it very easy to build Single Page Applications or SPAs",
    image: "../../images/react-blue.png",
    discuss: "4.2K",
    forward: "3.5K",
    like: "37.5K",
  },
];
