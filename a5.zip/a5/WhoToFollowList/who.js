export default [
  { avatarIcon: "java.png", userName: "Java", handle: "Java" },
  {
    avatarIcon: "relativity.jpeg",
    userName: "Relativity Space",
    handle: "relativityspace",
  },
  {
    avatarIcon: "virgin.png",
    userName: "Virgin Galactic",
    handle: "virgingalactic",
  },
  { avatarIcon: "nasa.png", userName: "NASA", handle: "NASA" },
  { avatarIcon: "tesla.png", userName: "Tesla", handle: "Tesla" },
];
